"""Agent 3: Quality Engineer (QA).

Inspects dynamic multi-file Python codebases for bugs, logic errors, and bad practices.
Supports both live Google Gemini (via google-genai) and deterministic local evaluation.
"""

import datetime
import logging
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from pydantic import BaseModel, Field
from google import genai
from google.genai import types

# Ensure backend root is on sys.path for direct script execution
_backend_dir = str(Path(__file__).resolve().parent.parent.parent)
if _backend_dir not in sys.path:
    sys.path.insert(0, _backend_dir)

from app.graph.state import AgentState
from app.core.config import settings
from app.core.llm import call_gemini_with_fallback

logger = logging.getLogger(__name__)

# Client picks up environment variable GEMINI_API_KEY automatically
try:
    client = genai.Client()
except Exception:
    client = None


class QAIssue(BaseModel):
    file_path: str = Field(description="The file path where the issue exists.")
    issue_type: str = Field(description="Category of issue (e.g., Bug, Code Smell, Edge Case).")
    description: str = Field(description="Detailed explanation of the flaw.")
    suggested_refactor: str = Field(description="Concrete refactored Python code snippet.")


class PonytailFinding(BaseModel):
    """A conservative Ponytail-style simplification finding; suggestions are not auto-applied."""
    tag: str = Field(description="One of delete, stdlib, native, yagni, shrink.")
    file_path: str = Field(description="Repository-relative file path.")
    finding: str = Field(description="What appears unnecessarily complex and why.")
    suggested_replacement: str = Field(description="A concrete simpler standard-library/native alternative, or 'none'.")
    risk_note: str = Field(default="", description="Compatibility or behavior risk to verify before changing code.")


class QAReport(BaseModel):
    passed: bool = Field(description="True if quality standards are met, False otherwise.")
    summary: str = Field(description="Overview of code quality assessment.")
    issues: list[QAIssue] = Field(description="List of identified QA issues and refactorings.")
    ponytail_findings: list[PonytailFinding] = Field(
        default_factory=list,
        description="Ranked, conservative findings for deleting over-engineering or replacing hand-rolled code with standard-library/native features. Suggestions only; never apply automatically."
    )


def analyze_code_qa_fallback(code_files: Dict[str, str]) -> QAReport:
    """Deterministic fallback QA analyzer when LLM API keys are not supplied or network fails."""
    issues: list[QAIssue] = []
    for path, content in code_files.items():
        if "TODO" in content:
            issues.append(QAIssue(
                file_path=path,
                issue_type="Code Smell",
                description="Unimplemented TODO markers detected.",
                suggested_refactor="# Implement planned logic or remove placeholder."
            ))
        if "except:" in content or "except Exception:" in content:
            issues.append(QAIssue(
                file_path=path,
                issue_type="Edge Case",
                description="Broad exception handler may conceal unexpected runtime faults.",
                suggested_refactor="except (ValueError, TypeError, KeyError) as err:\n    logger.error('Handled error: %s', err)"
            ))

    # Without an LLM, do not guess that a dependency or abstraction is replaceable:
    # a false positive could change runtime behavior. Report only conservative QA checks.
    passed = len(issues) == 0
    summary = (
        f"Local QA analysis completed. Found {len(issues)} potential issue(s). "
        f"Codebase standards {'satisfied' if passed else 'require attention'}. "
        "Ponytail-style simplification audit used conservative local checks; a full repository-wide "
        "stdlib/native audit requires the configured LLM review."
    )
    return QAReport(passed=passed, summary=summary, issues=issues, ponytail_findings=[])


def analyze_code_qa(code_files: Dict[str, str]) -> QAReport:
    """Invokes Gemini to inspect multi-file Python code for quality and bugs."""
    global client
    api_key = settings.gemini_api_key or os.getenv("GEMINI_API_KEY")
    if client is None and api_key:
        try:
            client = genai.Client(api_key=api_key)
        except Exception as init_exc:
            logger.warning("Failed to initialize GenAI client in QA agent: %s", init_exc)
            client = None

    if client is not None and code_files:
        try:
            system_instruction = (
                "You are a Senior QA Automation Engineer and conservative code-simplification auditor. "
                "Inspect the provided Python codebase for logic errors, unhandled exceptions, type mismatches, "
                "performance bottlenecks, bad practices, and missing tests. Provide concrete refactored code "
                "snippets for correctness issues. Also perform a Ponytail-style repository audit for "
                "over-engineering: identify dead code, hand-rolled functionality already provided by Python's "
                "standard library, functionality already provided by the platform, needless abstractions with "
                "one implementation, and logic that can be safely simplified. Rank the biggest safe reductions first. "
                "For each simplification finding use exactly one tag: delete, stdlib, native, yagni, or shrink. "
                "Give the file path, a specific replacement, and a risk/compatibility note. Do not invent findings "
                "just to produce output. Never recommend removing validation, error handling, security controls, "
                "data-loss protection, or accessibility. Do not automatically apply Ponytail findings; report them "
                "as recommendations for human review. Correctness, security, and performance issues belong in the "
                "normal QA/security review too."
            )

            formatted_code = "\n\n".join(
                f"--- File: {path} ---\n{content}" for path, content in code_files.items()
            )

            config = types.GenerateContentConfig(
                system_instruction=system_instruction,
                response_mime_type="application/json",
                response_schema=QAReport,
                temperature=0.1,
            )

            response = call_gemini_with_fallback(
                client=client,
                contents=(
                    "Review the following generated Python codebase. Return normal QA issues AND a separate "
                    "ranked ponytail_findings list. Ponytail finding tags: delete, stdlib, native, yagni, shrink. "
                    "Do not apply changes; suggest only evidence-backed, behavior-preserving simplifications.\n\n"
                    f"{formatted_code}"
                ),
                config=config,
                preferred_model=settings.default_model or "gemini-3.5-flash",
            )

            if response.parsed and isinstance(response.parsed, QAReport):
                return response.parsed
            if response.text:
                return QAReport.model_validate_json(response.text)
        except Exception as exc:
            logger.warning("Gemini QA analysis error, falling back: %s", exc)

    return analyze_code_qa_fallback(code_files)


def refactor_code(files: Dict[str, str]) -> Tuple[Dict[str, str], List[Dict[str, str]]]:
    """Refactors developer modules to adhere to standard library patterns and typing."""
    refactored = {}
    changelog = []

    for filename, content in files.items():
        if filename == "main.py":
            enhanced_content = content.replace(
                "    # Core domain business logic\n    result = {\n        \"status\": \"success\",\n        \"processed_items\": len(payload),\n        \"data\": payload\n    }\n    return result",
                "    # Refactored: Standardized response envelope with typing\n    from typing import cast\n    result: Dict[str, Any] = {\n        \"status\": \"success\",\n        \"processed_items\": len(payload),\n        \"data\": dict(payload),\n    }\n    return cast(Dict[str, Any], result)"
            )
            refactored[filename] = enhanced_content
            changelog.append({
                "file": filename,
                "type": "typing_and_immutability",
                "description": "Standardized response dictionary casting and shallow payload copy to prevent mutation."
            })
        elif filename == "utils.py":
            enhanced_content = content.replace(
                "def format_timestamp(dt) -> str:\n    \"\"\"Formats datetime to standard ISO 8601 string.\"\"\"\n    return dt.isoformat()",
                "from datetime import datetime, timezone\n\ndef format_timestamp(dt: Optional[datetime] = None) -> str:\n    \"\"\"Formats datetime to UTC ISO 8601 string, defaulting to current time.\"\"\"\n    target = dt or datetime.now(timezone.utc)\n    return target.isoformat()"
            )
            refactored[filename] = enhanced_content
            changelog.append({
                "file": filename,
                "type": "standard_library_datetime",
                "description": "Refactored timestamp formatting to use timezone-aware datetime standard library objects."
            })
        else:
            refactored[filename] = content

    return refactored, changelog


def qa_node(state: AgentState) -> Dict[str, Any]:
    """LangGraph node executing QA analysis."""
    code_files = state.get("generated_code") or state.get("dev_code_files", {})
    qa_report = analyze_code_qa(code_files)
    refactored_files, changelog = refactor_code(code_files)

    for issue in qa_report.issues:
        changelog.append({
            "file": issue.file_path,
            "type": issue.issue_type,
            "description": issue.description,
        })

    for finding in qa_report.ponytail_findings:
        changelog.append({
            "file": finding.file_path,
            "type": f"ponytail_{finding.tag}",
            "description": finding.finding,
            "suggested_replacement": finding.suggested_replacement,
            "risk_note": finding.risk_note,
        })

    timestamp = datetime.datetime.utcnow().isoformat()

    return {
        "qa_report": qa_report.model_dump(mode="json"),
        "qa_passed": qa_report.passed,
        "qa_refactored_files": refactored_files,
        "qa_changelog": changelog,
        "current_stage": "qa_completed",
        "logs": [{
            "agent": "QA",
            "stage": "qa_review",
            "message": f"QA Audit Complete (Passed: {qa_report.passed}, Issues: {len(qa_report.issues)}, "
            f"Ponytail Findings: {len(qa_report.ponytail_findings)})",
            "timestamp": timestamp,
        }],
    }
